/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: technostore
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `albaranes`
--

DROP TABLE IF EXISTS `albaranes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `albaranes` (
  `id_albaran` int(11) NOT NULL AUTO_INCREMENT,
  `id_proveedor` int(11) NOT NULL,
  `fecha_recepcion` datetime DEFAULT current_timestamp(),
  `coste_total` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_albaran`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `albaranes_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedores` (`id_proveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `albaranes`
--

LOCK TABLES `albaranes` WRITE;
/*!40000 ALTER TABLE `albaranes` DISABLE KEYS */;
/*!40000 ALTER TABLE `albaranes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carrito`
--

DROP TABLE IF EXISTS `carrito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `carrito` (
  `id_carrito` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `fecha_creacion` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id_carrito`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `carrito_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carrito`
--

LOCK TABLES `carrito` WRITE;
/*!40000 ALTER TABLE `carrito` DISABLE KEYS */;
INSERT INTO `carrito` VALUES
(3,1,'2026-02-25 18:14:41'),
(4,2,'2026-02-25 19:15:37'),
(5,5,'2026-02-27 15:49:36');
/*!40000 ALTER TABLE `carrito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalles_carrito`
--

DROP TABLE IF EXISTS `detalles_carrito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalles_carrito` (
  `id_detalle_carrito` int(11) NOT NULL AUTO_INCREMENT,
  `id_carrito` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL DEFAULT 1,
  `fecha_agregado` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id_detalle_carrito`),
  KEY `id_carrito` (`id_carrito`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `detalles_carrito_ibfk_1` FOREIGN KEY (`id_carrito`) REFERENCES `carrito` (`id_carrito`) ON DELETE CASCADE,
  CONSTRAINT `detalles_carrito_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalles_carrito`
--

LOCK TABLES `detalles_carrito` WRITE;
/*!40000 ALTER TABLE `detalles_carrito` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalles_carrito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalles_pedido`
--

DROP TABLE IF EXISTS `detalles_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalles_pedido` (
  `id_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `id_pedido` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_detalle`),
  KEY `id_pedido` (`id_pedido`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `detalles_pedido_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`) ON DELETE CASCADE,
  CONSTRAINT `detalles_pedido_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalles_pedido`
--

LOCK TABLES `detalles_pedido` WRITE;
/*!40000 ALTER TABLE `detalles_pedido` DISABLE KEYS */;
INSERT INTO `detalles_pedido` VALUES
(1,1,1,1,1899.99),
(2,1,5,1,479.99),
(3,1,7,1,689.99),
(4,2,20,1,429.99),
(5,2,21,1,659.99),
(6,2,3,1,849.99),
(7,2,1,1,1899.99),
(8,2,23,1,299.99),
(9,2,22,1,549.99),
(10,3,25,1,289.99),
(11,3,36,1,1599.99),
(12,3,13,1,229.99),
(13,3,33,1,165.99),
(14,3,46,1,289.99),
(15,4,13,1,229.99),
(16,4,16,1,249.99),
(17,4,25,1,289.99),
(18,4,36,1,1599.99),
(19,5,13,1,229.99),
(20,5,16,1,249.99),
(21,6,21,1,659.99),
(22,6,20,1,429.99);
/*!40000 ALTER TABLE `detalles_pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedidos` (
  `id_pedido` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `fecha_pedido` datetime DEFAULT current_timestamp(),
  `estado` enum('Pendiente','Procesando','Enviado','Entregado','Cancelado') DEFAULT 'Pendiente',
  `total` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_pedido`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos`
--

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
INSERT INTO `pedidos` VALUES
(1,1,'2026-02-25 18:14:47','Cancelado',3069.97),
(2,1,'2026-02-25 19:14:46','Cancelado',4689.94),
(3,2,'2026-02-25 19:15:50','Cancelado',2575.95),
(4,2,'2026-02-25 19:19:24','Cancelado',2369.96),
(5,2,'2026-02-25 19:26:43','Cancelado',479.98),
(6,5,'2026-02-27 15:53:35','Procesando',1089.98);
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `id_producto` int(11) NOT NULL AUTO_INCREMENT,
  `id_proveedor` int(11) DEFAULT NULL,
  `nombre` varchar(150) NOT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `stock_actual` int(11) DEFAULT 0,
  `ruta_imagen` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_producto`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedores` (`id_proveedor`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES
(1,1,'GeForce RTX 4090 Founders Edition 24GB','grafica','La GPU más potente del mercado 2026. 24 GB GDDR6X, DLSS 4, Frame Generation y Ray Tracing de nueva generación. Ideal para 4K/8K y creación de contenido.',1899.99,12,'imagenes/GeForce_RTX_4090_Founders_Edition_24GB.png'),
(2,1,'GeForce RTX 5080 16GB','grafica','Nueva generación Blackwell. Excelente equilibrio rendimiento/precio para gaming 4K ultra y streaming.',1299.99,18,'imagenes/GeForce_RTX_5080_16GB.png'),
(3,1,'GeForce RTX 5070 Ti 12GB','grafica','Perfecta para 1440p/4K a 120+ FPS con DLSS 4. Muy demandada por gamers.',849.99,25,'imagenes/GeForce_RTX_5070_Ti_12GB.png'),
(4,2,'Ryzen 9 9950X 16 núcleos','procesador','Procesador Zen 5 de 16 núcleos/32 hilos. El rey de la productividad y creación de contenido 2026.',679.99,9,'imagenes/Ryzen_9_9950X.png'),
(5,2,'Ryzen 7 9800X3D','procesador','El mejor procesador gaming del mundo gracias al 3D V-Cache. Hasta 25% más FPS que la competencia.',479.99,31,'imagenes/Ryzen_7_9800X3D.png'),
(6,2,'Radeon RX 8900 XTX 24GB','grafica','GPU AMD flagship 2026. Excelente rasterización y FSR 4. Gran alternativa a NVIDIA.',1049.99,14,'imagenes/Radeon_RX_8900_XTX_24GB.png'),
(7,3,'Core i9-15900K 24 núcleos','procesador','Procesador Arrow Lake flagship. 24 núcleos (8P+16E), ideal para gaming extremo y edición.',689.99,16,'imagenes/Core_i9-15900K_24_nucleos.png'),
(8,3,'Core i7-15700K','procesador','Gran equilibrio precio/rendimiento para gaming y multitarea.',449.99,22,'imagenes/Core_i7-15700K.png'),
(9,4,'ROG Strix Z890-E Gaming WiFi','placa base','Placa base premium ASUS para Intel Arrow Lake. WiFi 7, PCIe 5.0, VRM de 20 fases.',499.99,8,'imagenes/ROG_Strix_Z890-E_Gaming_WiFi.png'),
(10,5,'MAG B850 Tomahawk WiFi','placa base','Placa base MSI para AMD Ryzen 9000. Excelente calidad-precio y refrigeración.',229.99,19,'imagenes/MAG_B850_Tomahawk_WiFi.png'),
(11,6,'Vengeance RGB DDR5 6000MHz 32GB (2x16GB)','ram','Kit Corsair DDR5 CL30 con iluminación RGB espectacular. Compatible Intel/AMD.',139.99,42,'imagenes/Corsair_Vengeance_RGB_DDR5_32GB_6000MHz.png'),
(12,7,'Fury Beast DDR5 6400MHz 64GB (2x32GB)','ram','Kingston DDR5 de alta capacidad y velocidad. Ideal para workstations y gaming.',269.99,11,'imagenes/Fury_Beast_DDR5_6400MHz_64GB.png'),
(13,8,'990 EVO Plus 2TB PCIe 5.0 NVMe','ssd','SSD Samsung de última generación. Velocidades de hasta 14.000 MB/s lectura.',229.99,37,'imagenes/990_EVO.png'),
(14,10,'WD Black SN850X 4TB','ssd','SSD NVMe Gen4 de alto rendimiento para gamers y creadores de contenido.',349.99,15,'imagenes/WD_Black_SN850X_4TB.png'),
(15,9,'Gigabyte GeForce RTX 5070 Gaming OC 12GB','grafica','Versión overclockeada de fábrica con excelente refrigeración Windforce.',899.99,13,'imagenes/Gigabyte_GeForce_RTX_5070_Gaming_OC_12GB.png'),
(16,2,'AMD Ryzen 5 7600X','procesador','Procesador de 6 núcleos y 12 hilos, ideal para gaming a precio ajustado.',249.99,25,'imagenes/Ryzen_5_7600X.png'),
(17,2,'AMD Ryzen 7 7800X3D','procesador','El rey del gaming actual gracias a su tecnología 3D V-Cache.',419.99,15,'imagenes/Ryzen_7_7800X3D.png'),
(18,3,'Intel Core i5-14600K','procesador','Excelente procesador de 14 núcleos para multitarea y juegos.',329.99,30,'imagenes/Intel_Core_i5-14600K.png'),
(19,3,'Intel Core i7-14700K','procesador','Rendimiento bestial de 20 núcleos para creación de contenido y streaming.',459.99,12,'imagenes/Intel_Core_i7-14700K.png'),
(20,1,'GeForce RTX 4060 Ti 8GB','grafica','Gráfica ideal para jugar a 1080p en Ultra con DLSS 3.',429.99,18,'imagenes/GeForce_RTX_4060_Ti_8GB.png'),
(21,1,'GeForce RTX 4070 SUPER 12GB','grafica','El punto dulce para jugar a 1440p con Ray Tracing activado.',659.99,10,'imagenes/GeForce_RTX_4070_SUPER_12GB.png'),
(22,2,'Radeon RX 7800 XT 16GB','grafica','Potencia bruta espectacular y mucha VRAM para resoluciones altas.',549.99,22,'imagenes/Radeon_RX_7800_XT_16GB.png'),
(23,2,'Radeon RX 7600 8GB','grafica','La opción más económica para jugar a todo hoy en día.',299.99,35,'imagenes/Radeon_RX_7600_8GB.png'),
(24,5,'MSI MAG B650 TOMAHAWK WIFI','placa base','Placa base robusta para AMD AM5 con excelente conectividad.',219.99,14,'imagenes/MSI_MAG_B650_TOMAHAWK_WIFI.png'),
(25,4,'ASUS ROG STRIX B650E-F','placa base','Placa base premium con PCIe 5.0 para el futuro.',289.99,8,'imagenes/ASUS_ROG_STRIX_B650E-F.png'),
(26,9,'Gigabyte Z790 AORUS ELITE AX','placa base','Para procesadores Intel de 14ª generación con soporte DDR5.',259.99,11,'imagenes/Gigabyte_Z790_AORUS_ELITE_AX.png'),
(27,4,'ASUS TUF GAMING B760-PLUS WIFI','placa base','Durabilidad militar y rendimiento estable para CPUs Intel.',189.99,20,'imagenes/ASUS_TUF_GAMING_B760-PLUS_WIFI.png'),
(28,6,'Corsair Vengeance RGB DDR5 32GB 6000MHz','ram','Memoria rápida con iluminación RGB personalizable.',135.99,40,'imagenes/Corsair_Vengeance_RGB_DDR5_32GB_6000MHz.png'),
(29,7,'Kingston FURY Beast DDR4 16GB 3200MHz','ram','El estándar perfecto para ordenadores de presupuesto medio.',45.99,60,'imagenes/Kingston_FURY_Beast_DDR4_16GB_3200MHz.png'),
(30,6,'Corsair Dominator Titanium DDR5 64GB','ram','La joya de la corona en memoria RAM. Latencias bajísimas.',299.99,5,'imagenes/Corsair_Dominator_Titanium_DDR5_64GB.png'),
(31,7,'Kingston FURY Renegade DDR5 32GB 6400MHz','ram','Memoria extrema para sacar el máximo partido a tu PC.',159.99,18,'imagenes/Kingston_FURY_Renegade_DDR5_32GB_6400MHz.png'),
(32,8,'Samsung 980 PRO 1TB NVMe M.2','ssd','Velocidad PCIe 4.0 líder en la industria.',95.99,50,'imagenes/Samsung_980_PRO_1TB_NVMe_M.2.png'),
(33,10,'WD Black SN850X 2TB NVMe','ssd','Capacidad masiva y velocidades de carga ultrarrápidas para juegos.',165.99,25,'imagenes/WD_Black_SN850X_2TB_NVMe.png'),
(34,8,'Samsung 870 EVO 1TB SATA','ssd','Almacenamiento SATA muy fiable para datos masivos.',89.99,30,'imagenes/Samsung_870_EVO_1TB.png'),
(35,10,'WD Blue SN580 1TB NVMe','ssd','La mejor relación calidad-precio para uso diario.',65.99,45,'imagenes/WD_Blue_SN580_1TB_NVMe.png'),
(36,4,'ASUS ROG Zephyrus G14','portatil gaming','Compacto de 14\", Ryzen 9 y RTX 4060. Portabilidad y potencia.',1599.99,6,'imagenes/ASUS_ROG_Zephyrus_G14.png'),
(37,5,'MSI Raider GE78 HX','portatil gaming','El monstruo de los portátiles. i9 y RTX 4080. Sustituto de sobremesa.',2499.99,3,'imagenes/MSI_Raider_GE78_HX.png'),
(38,11,'Lenovo Legion Pro 5i','portatil gaming','Rendimiento térmico impecable, pantalla 16\" a 165Hz.',1399.99,12,'imagenes/Lenovo_Legion_Pro_5i.png'),
(39,14,'Razer Blade 16','portatil gaming','Chasis unibody de aluminio, pantalla Mini-LED y RTX 4070.',2899.99,2,'imagenes/Razer_Blade_16.png'),
(40,12,'Dell XPS 15','portatil','Pantalla OLED sin bordes, ideal para creadores de contenido.',1799.99,7,'imagenes/Dell_XPS_15.png'),
(41,11,'Lenovo ThinkPad X1 Carbon','portatil','Ultra ligero, teclado legendario y seguridad empresarial.',1649.99,9,'imagenes/Lenovo_ThinkPad_X1_Carbon.png'),
(42,4,'ASUS ZenBook 14 OLED','portatil','Elegante, batería infinita y una pantalla OLED de colores vibrantes.',1099.99,14,'imagenes/ASUS_ZenBook_14_OLED.png'),
(43,13,'HP Spectre x360','portatil','Convertible premium con lápiz táctil incluido.',1499.99,5,'imagenes/HP_Spectre_x360.png'),
(44,16,'LG UltraGear 27GP850-B 27\"','monitor','Panel NanoIPS, 1440p y 165Hz. El favorito de los gamers.',349.99,16,'imagenes/LG_UltraGear_27GP850-B.png'),
(45,8,'Samsung Odyssey G7 32\"','monitor','Monitor curvo extremo, 1440p a 240Hz. Inmersión total.',599.99,8,'imagenes/Samsung_Odyssey_G7.png'),
(46,4,'ASUS TUF Gaming VG27AQ','monitor','Fiabilidad y compatibilidad G-Sync a un gran precio.',289.99,21,'imagenes/ASUS_TUF_Gaming_VG27AQ.png'),
(47,12,'Dell Alienware AW3423DWF OLED','monitor','Ultrapanorámico OLED, colores perfectos y negros absolutos.',899.99,4,'imagenes/Dell_Alienware_AW3423DWF_OLED.png'),
(48,15,'Logitech G Pro X Superlight','periferico','Ratón inalámbrico superligero para eSports.',119.99,28,'imagenes/Logitech_G_Pro_X_Superlight.png'),
(49,14,'Razer Huntsman V2','periferico','Teclado óptico-mecánico con la respuesta más rápida del mercado.',189.99,12,'imagenes/Razer_Huntsman_V2.png'),
(50,6,'Corsair Virtuoso RGB Wireless','periferico','Auriculares gaming con sonido de alta fidelidad y micro broadcast.',179.99,15,'imagenes/Corsair_Virtuoso_RGB_Wireless.png'),
(51,15,'Logitech MX Master 3S','periferico','El mejor ratón para productividad y trabajo de diseño.',105.99,22,'imagenes/Logitech_MX_Master_3S.png'),
(52,3,'Intel Core i3-12100F','procesador','Procesador de entrada ideal para ofimática y gaming básico. (Agotado temporalmente)',89.99,0,'imagenes/Intel_Core_i3-12100F.png'),
(53,1,'GeForce GTX 1650 4GB','grafica','Tarjeta gráfica económica para 1080p. Perfecta para presupuestos ajustados.',159.99,0,'imagenes/GeForce_GTX_1650_4GB.png'),
(54,9,'Gigabyte B550M DS3H','placa base','Placa base Micro-ATX muy popular para procesadores AM4.',89.99,0,'imagenes/Gigabyte_B550M_DS3H.png'),
(55,6,'Corsair Vengeance LPX DDR4 16GB 3200MHz','ram','Memoria RAM DDR4 súper ventas de perfil bajo.',39.99,0,'imagenes/Corsair_Vengeance_LPX_DDR4_16GB_3200MHz.png'),
(56,7,'Kingston NV2 500GB PCIe 4.0 NVMe','ssd','Almacenamiento rápido y muy asequible para arrancar el sistema.',35.99,0,'imagenes/Kingston_NV2_500GB_PCIe_4.0_NVMe.png'),
(57,13,'HP Victus 16','portatil gaming','Portátil gaming de entrada con pantalla de 144Hz.',799.99,0,'imagenes/HP_Victus_16.png'),
(58,12,'Dell Inspiron 15','portatil','Portátil ligero y fiable, perfecto para estudiantes y trabajo de oficina.',549.99,0,'imagenes/Dell_Inspiron_15.png'),
(59,16,'LG 24GQ50F-B 24\"','monitor','Monitor gaming asequible de 165Hz y panel VA.',149.99,0,'imagenes/LG_24GQ50F-B.png'),
(60,14,'Razer DeathAdder V2','periferico','Ratón ergonómico clásico para eSports con sensor de 20K DPI.',49.99,0,'imagenes/Razer_DeathAdder_V2.png');
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedores` (
  `id_proveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_empresa` varchar(150) NOT NULL,
  `contacto` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` VALUES
(1,'NVIDIA','Ventas NVIDIA España','+34 900 123 456'),
(2,'AMD','AMD Iberia','+34 900 654 321'),
(3,'Intel','Intel Partner Program','+34 900 987 654'),
(4,'ASUS','ASUS España','+34 910 000 111'),
(5,'MSI','MSI España','+34 910 222 333'),
(6,'Corsair','Corsair EU Support','+44 20 1234 5678'),
(7,'Kingston','Kingston Technology','+34 910 444 555'),
(8,'Samsung','Samsung Electronics','+34 910 666 777'),
(9,'Gigabyte','Gigabyte España','+34 910 888 999'),
(10,'Western Digital','WD España','+34 910 111 222'),
(11,'Lenovo','Lenovo Iberia','+34 910 111 333'),
(12,'Dell','Dell España','+34 910 222 444'),
(13,'HP','HP Enterprise','+34 910 333 555'),
(14,'Razer','Razer Europe','+44 20 8888 9999'),
(15,'Logitech','Logitech España','+34 910 444 666'),
(16,'LG','LG Electronics','+34 910 555 777');
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id_rol` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_rol` varchar(50) NOT NULL,
  PRIMARY KEY (`id_rol`),
  UNIQUE KEY `nombre_rol` (`nombre_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'admin'),
(2,'cliente');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sesiones_cookies`
--

DROP TABLE IF EXISTS `sesiones_cookies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sesiones_cookies` (
  `id_sesion` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `token` varchar(64) NOT NULL,
  `fecha_expiracion` datetime NOT NULL,
  `ip_hasheada` varchar(64) NOT NULL,
  `cookies_tecnicas` tinyint(1) DEFAULT 1,
  `cookies_analytics` tinyint(1) NOT NULL DEFAULT 0,
  `cookies_marketing` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_sesion`),
  UNIQUE KEY `token` (`token`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `sesiones_cookies_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sesiones_cookies`
--

LOCK TABLES `sesiones_cookies` WRITE;
/*!40000 ALTER TABLE `sesiones_cookies` DISABLE KEYS */;
INSERT INTO `sesiones_cookies` VALUES
(1,NULL,'734b7b67ee287a8281ed6a9699042b297ea700644080d4c031e3453ed035adf5','2027-02-27 17:13:01','acd4fa2a8a5814117fd5807bd0f243ca505ded62ecc77587402fbbff2874090b',1,1,1);
/*!40000 ALTER TABLE `sesiones_cookies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `id_rol` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `fecha_registro` datetime DEFAULT current_timestamp(),
  `bloqueado` tinyint(1) DEFAULT 0,
  `email_interno` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `email` (`email`),
  KEY `id_rol` (`id_rol`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES
(1,1,'Alejandro','amarin11@educa.madrid.org','$2y$10$ONGfz5HwqIPnnbRq.mgUbehmEFbdJfgowQOjIMTh3Wfm8bM3Eluqu','2026-02-24 15:33:25',0,'amarin11@technostore.com'),
(2,2,'Izan Morcillo','izxn27@gmail.com','$2y$10$C96ANT1b3imxCOI8V0aHauSRrK3j6IJYoVk0l46TQ3JroxPiXywTO','2026-02-25 19:06:52',0,NULL),
(3,2,'Ismael Herrero','ismaelherrero513@gmail.com','$2y$10$9Q9cANXg1CGcuChIjinGsehssfSWVUQpZ3N65vbzPPGc2yg9Xz5Iq','2026-02-25 19:07:40',0,NULL),
(4,1,'Ismael Herrero','ismael.herrero@educa.madrid.com','$2y$10$RWHySQ3Pqr7.ZDPzhT6PqO03kN0qgNiLIt5nCkWN9/OQiDX9cM5ye','2026-02-27 15:04:21',0,'ismael.herrero@technostore.com'),
(5,1,'Izan Morcillo','izan.morcillo1@educa.madrid.org','$2y$10$TlDW/mHUiM35J/CPEulaSOJI4Z.8YxBg3EwtnuJrP9p9ZAC3r0MM6','2026-02-27 15:41:56',0,'izan.morcillo1@technostore.com');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-27 18:44:42
